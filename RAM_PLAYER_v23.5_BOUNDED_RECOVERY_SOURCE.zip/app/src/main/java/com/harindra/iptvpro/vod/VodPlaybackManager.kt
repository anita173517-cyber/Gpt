package com.harindra.iptvpro.vod

import android.app.ActivityManager
import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.harindra.iptvpro.AudioDelayProcessor
import com.harindra.iptvpro.NetworkClient
import com.harindra.iptvpro.RamPlayerPlaybackService
import java.util.Locale

/**
 * Independently Managed Dedicated VOD ExoPlayer Lifecycle & Configuration Manager.
 *
 * - Owns its own [ExoPlayer], [DefaultTrackSelector], and [AudioDelayProcessor] instance.
 * - NEVER touches Live TV's ExoPlayer, PlayerView, channel state, or reconnect logic.
 * - Uses device-adaptive VOD buffering safe for 512MB, 1GB, 2GB, and 4GB+ Android TVs.
 * - Preserves provider-compatible OkHttp networking, cookies, headers, and redirects.
 */
@OptIn(UnstableApi::class)
class VodPlaybackManager(
    private val context: Context,
    private val prefs: VodPreferencesStore
) {
    private var vodPlayer: ExoPlayer? = null
    private var trackSelector: DefaultTrackSelector? = null
    val audioDelayProcessor: AudioDelayProcessor = AudioDelayProcessor()

    fun getPlayer(): ExoPlayer? = vodPlayer

    fun getOrCreatePlayer(): ExoPlayer {
        vodPlayer?.let { return it }

        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val memInfo = ActivityManager.MemoryInfo()
        val totalRamMb = if (am != null) {
            am.getMemoryInfo(memInfo)
            memInfo.totalMem / (1024L * 1024L)
        } else 2048L
        val isLowRam = am?.isLowRamDevice == true || totalRamMb <= 1024L

        // Device-adaptive VOD LoadControl: smooth seeking & playback without preloading entire movies
        val minBufferMs = if (isLowRam) 12_000 else 20_000
        val maxBufferMs = if (isLowRam) 28_000 else 50_000
        val playbackBufferMs = if (isLowRam) 1_800 else 2_500
        val rebufferMs = if (isLowRam) 3_500 else 4_500
        val targetBufferBytes = if (isLowRam) 16 * 1024 * 1024 else 40 * 1024 * 1024

        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(minBufferMs, maxBufferMs, playbackBufferMs, rebufferMs)
            .setTargetBufferBytes(targetBufferBytes)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()

        val selector = DefaultTrackSelector(context).apply {
            val paramsBuilder = buildUponParameters()
                .setExceedVideoConstraintsIfNecessary(true)
                .setExceedAudioConstraintsIfNecessary(true)
                .setTunnelingEnabled(false)
            val prefAudio = prefs.getPreferredAudioLanguage()
            if (prefAudio.isNotBlank() && prefAudio != "original" && prefAudio != "auto") {
                paramsBuilder.setPreferredAudioLanguage(prefAudio)
            }
            if (!prefs.isSubtitlesDefaultEnabled()) {
                paramsBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
            } else {
                paramsBuilder.setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
                val prefSub = prefs.getPreferredSubtitleLanguage()
                if (prefSub.isNotBlank() && prefSub != "auto") {
                    paramsBuilder.setPreferredTextLanguage(prefSub)
                }
            }
            setParameters(paramsBuilder)
        }
        trackSelector = selector

        val renderersFactory = object : DefaultRenderersFactory(context) {
            override fun buildAudioSink(
                context: Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setEnableFloatOutput(enableFloatOutput)
                    .setEnableAudioTrackPlaybackParams(enableAudioTrackPlaybackParams)
                    .setAudioProcessors(arrayOf(audioDelayProcessor))
                    .build()
            }
        }.apply {
            setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            setEnableDecoderFallback(true)
        }

        val okHttpFactory = OkHttpDataSource.Factory(NetworkClient.streamClient)
        val mediaSourceFactory = DefaultMediaSourceFactory(okHttpFactory)

        val audioAttrs = AudioAttributes.Builder()
            .setUsage(C.USAGE_MEDIA)
            .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
            .build()

        val player = ExoPlayer.Builder(context, renderersFactory)
            .setTrackSelector(selector)
            .setLoadControl(loadControl)
            .setMediaSourceFactory(mediaSourceFactory)
            .setAudioAttributes(audioAttrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_NETWORK)
            .build()

        player.setPlaybackSpeed(prefs.getDefaultPlaybackSpeed().rate)
        vodPlayer = player
        RamPlayerPlaybackService.registerVodPlayer(player)
        return player
    }

    fun prepareMedia(
        streamUrl: String,
        resumePositionMs: Long,
        externalSubtitleUrl: String = "",
        externalSubtitleLanguage: String = "en"
    ): Boolean {
        val cleanUrl = streamUrl.trim()
        if (cleanUrl.isEmpty() || (!cleanUrl.startsWith("http://", true) && !cleanUrl.startsWith("https://", true))) {
            return false
        }
        val player = getOrCreatePlayer()
        val mediaItemBuilder = MediaItem.Builder().setUri(Uri.parse(cleanUrl))

        val extSub = externalSubtitleUrl.trim()
        if (extSub.startsWith("http://", true) || extSub.startsWith("https://", true)) {
            val mime = guessSubtitleMimeType(extSub)
            if (mime != null) {
                val subConfig = MediaItem.SubtitleConfiguration.Builder(Uri.parse(extSub))
                    .setId("ext_sub_0")
                    .setMimeType(mime)
                    .setLanguage(externalSubtitleLanguage.ifBlank { "en" })
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
                    .build()
                mediaItemBuilder.setSubtitleConfigurations(listOf(subConfig))
            }
        }

        val safeStartMs = resumePositionMs.coerceAtLeast(0L)
        player.setMediaItem(mediaItemBuilder.build(), safeStartMs)
        player.setPlaybackSpeed(prefs.getDefaultPlaybackSpeed().rate)
        player.prepare()
        player.playWhenReady = true
        return true
    }

    fun applyAspectRatio(playerView: PlayerView, mode: VodAspectRatioMode) {
        when (mode) {
            VodAspectRatioMode.FIT -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                playerView.scaleX = 1.0f
                playerView.scaleY = 1.0f
            }
            VodAspectRatioMode.FILL -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                playerView.scaleX = 1.0f
                playerView.scaleY = 1.0f
            }
            VodAspectRatioMode.ZOOM -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                playerView.scaleX = 1.12f
                playerView.scaleY = 1.12f
            }
            VodAspectRatioMode.STRETCH -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FILL
                playerView.scaleX = 1.0f
                playerView.scaleY = 1.0f
            }
            VodAspectRatioMode.ORIGINAL -> {
                playerView.resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                playerView.scaleX = 0.92f
                playerView.scaleY = 0.92f
            }
        }
    }

    fun guessSubtitleMimeType(url: String): String? {
        val lower = url.substringBefore('?').lowercase(Locale.ROOT)
        return when {
            lower.endsWith(".vtt") -> MimeTypes.TEXT_VTT
            lower.endsWith(".srt") -> MimeTypes.APPLICATION_SUBRIP
            lower.endsWith(".ttml") || lower.endsWith(".xml") -> MimeTypes.APPLICATION_TTML
            lower.endsWith(".ssa") || lower.endsWith(".ass") -> MimeTypes.TEXT_SSA
            else -> null
        }
    }

    fun pause() {
        vodPlayer?.playWhenReady = false
    }

    fun resume() {
        vodPlayer?.playWhenReady = true
    }

    fun release() {
        val p = vodPlayer
        vodPlayer = null
        trackSelector = null
        if (p != null) {
            RamPlayerPlaybackService.unregisterVodPlayer(p)
            runCatching {
                p.playWhenReady = false
                p.stop()
                p.clearMediaItems()
                p.release()
            }
        }
    }
}
