package com.harindra.iptvpro.vod

/**
 * Dedicated Advanced Seeking Controller for VOD Playback.
 *
 * - Supports configurable intervals: 5s, 10s (default), 15s, 20s, 30s, 60s.
 * - Supports single-press seek and long-press continuous accelerated scrubbing with live preview.
 * - Strictly clamps target positions to valid media duration and handles unknown duration / live-like VOD safely.
 */
data class VodSeekPreviewState(
    val isScrubbing: Boolean = false,
    val originPositionMs: Long = 0L,
    val targetPositionMs: Long = 0L,
    val deltaMs: Long = 0L,
    val durationMs: Long = 0L,
    val isForward: Boolean = true
) {
    fun formattedDelta(): String = VodTimeFormatter.formatSignedDeltaMs(deltaMs)
    fun formattedTarget(): String = VodTimeFormatter.formatMs(targetPositionMs)
    fun formattedDuration(): String = if (durationMs > 0L) VodTimeFormatter.formatMs(durationMs) else "--:--"
}

class VodSeekController(
    private var defaultInterval: VodSeekInterval = VodSeekInterval.SEC_10
) {
    private var continuousActive: Boolean = false
    private var continuousOriginMs: Long = 0L
    private var continuousTargetMs: Long = 0L
    private var continuousRepeatCount: Int = 0
    private var continuousDurationMs: Long = 0L
    private var continuousIsForward: Boolean = true

    fun setDefaultInterval(interval: VodSeekInterval) {
        defaultInterval = interval
    }

    fun getDefaultInterval(): VodSeekInterval = defaultInterval

    fun clampPosition(targetMs: Long, durationMs: Long): Long {
        if (targetMs <= 0L) return 0L
        if (durationMs > 0L) {
            return targetMs.coerceIn(0L, durationMs)
        }
        return targetMs
    }

    /**
     * Computes a single rewind or fast-forward target from the actual Media3 playback position.
     */
    fun computeStepSeek(
        currentPositionMs: Long,
        durationMs: Long,
        isSeekable: Boolean,
        isForward: Boolean,
        intervalOverride: VodSeekInterval? = null
    ): VodSeekPreviewState? {
        if (!isSeekable) return null
        val step = (intervalOverride ?: defaultInterval).millis
        val signedStep = if (isForward) step else -step
        val safeCurrent = currentPositionMs.coerceAtLeast(0L)
        val clamped = clampPosition(safeCurrent + signedStep, durationMs)
        return VodSeekPreviewState(
            isScrubbing = false,
            originPositionMs = safeCurrent,
            targetPositionMs = clamped,
            deltaMs = clamped - safeCurrent,
            durationMs = durationMs.coerceAtLeast(0L),
            isForward = isForward
        )
    }

    /**
     * Advances a continuous long-press seek with smooth acceleration (1x -> 2x -> 3x -> 4x).
     */
    fun onContinuousSeekStep(
        currentPositionMs: Long,
        durationMs: Long,
        isSeekable: Boolean,
        isForward: Boolean
    ): VodSeekPreviewState? {
        if (!isSeekable) return null
        val safeCurrent = currentPositionMs.coerceAtLeast(0L)
        if (!continuousActive || continuousIsForward != isForward) {
            continuousActive = true
            continuousOriginMs = safeCurrent
            continuousTargetMs = safeCurrent
            continuousRepeatCount = 0
            continuousDurationMs = durationMs.coerceAtLeast(0L)
            continuousIsForward = isForward
        }
        continuousRepeatCount++
        val multiplier = when {
            continuousRepeatCount >= 16 -> 4L
            continuousRepeatCount >= 10 -> 3L
            continuousRepeatCount >= 5 -> 2L
            else -> 1L
        }
        val step = defaultInterval.millis * multiplier
        val signedStep = if (isForward) step else -step
        continuousTargetMs = clampPosition(continuousTargetMs + signedStep, continuousDurationMs)
        return VodSeekPreviewState(
            isScrubbing = true,
            originPositionMs = continuousOriginMs,
            targetPositionMs = continuousTargetMs,
            deltaMs = continuousTargetMs - continuousOriginMs,
            durationMs = continuousDurationMs,
            isForward = isForward
        )
    }

    fun commitContinuousSeek(): Long? {
        if (!continuousActive) return null
        val target = continuousTargetMs
        cancelContinuousSeek()
        return target
    }

    fun cancelContinuousSeek() {
        continuousActive = false
        continuousOriginMs = 0L
        continuousTargetMs = 0L
        continuousRepeatCount = 0
        continuousDurationMs = 0L
    }

    fun isContinuousScrubbing(): Boolean = continuousActive
}
