# RAM PLAYER v23.5 — Bounded Live Playback Recovery

## Changes
- Live TV stall watchdog now performs at most one same-engine Media3 re-prepare, then one eligible engine/format failover; it no longer loops through three repeated prepare attempts and force-reloads the channel indefinitely.
- Media3 Live TV error handling now allows one same-engine retry, then attempts the existing eligible engine failover once. If no failover is available, it reports the stream as unavailable instead of continuing repeated retries.
- User-Agent compatibility probing is capped at three candidates (cached winner plus up to two alternatives). HTTP 429 and 503 no longer trigger User-Agent rotation because those indicate throttling/server availability, not necessarily client identity.
- App version metadata bumped to 23.5 / versionCode 235.

## Preserved
Existing Live TV UI, Movies/Series player, playlist/account features, Media3/LibVLC engines, buffer profile settings, EPG, favorites, and GitHub Actions workflows were not intentionally redesigned.

## Important limitations
This is a source-level stability patch, not a guarantee of zero buffering. Buffering can still occur due to IPTV server congestion, expired/blocked URLs, codec/decoder incompatibility, packet loss, or insufficient device hardware. No real 512 MB TV playback test was performed in this environment. Build verification must be run in GitHub Actions before installing.
